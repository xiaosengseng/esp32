#include <stdio.h>
#include "esp_types.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"

#define GPIO_OUTPUT_0   16
#define GPIO_OUTPUT_1   18
#define GPIO_OUTPUT_2   19

void gpio_config_set()             //GPIO结构初始化
{
	gpio_config_t io_conf;
	io_conf.intr_type=GPIO_PIN_INTR_DISABLE;
	io_conf.mode=GPIO_MODE_OUTPUT;
	io_conf.pin_bit_mask=GPIO_SEL_16;
	io_conf.pull_down_en=0;
	io_conf.pull_up_en=0;
	gpio_config(&io_conf);
}

void app_main()
{
	//第一种方式
    gpio_pad_select_gpio(GPIO_NUM_16);                      //选择一个GPIO16
	gpio_set_direction(GPIO_NUM_16,GPIO_MODE_OUTPUT);       //这个GPIO的模式为输出
	gpio_pad_select_gpio(GPIO_NUM_16);                      //选择一个GPIO18
	gpio_set_direction(GPIO_NUM_18,GPIO_MODE_OUTPUT);       //这个GPIO的模式为输出
	gpio_pad_select_gpio(GPIO_NUM_18);                      //选择一个GPIO19
	gpio_set_direction(GPIO_NUM_19,GPIO_MODE_OUTPUT);       //这个GPIO的模式为输出  
	//第二种方式
	//gpio_config_set();
	const int time_ms = 500;

	//gpio_set_level(GPIO_OUTPUT_0,1);                        //GPIO引脚输出函数
	while(1)
	{
		gpio_set_level(GPIO_OUTPUT_0,1);                        //GPIO引脚输出函数
		printf("IO16 Level is:%d  \n\r\n",gpio_get_level(GPIO_OUTPUT_0));
		vTaskDelay(time_ms);

		gpio_set_level(GPIO_OUTPUT_0,0);                        //GPIO引脚输出函数
		printf("IO16 Level is:%d  \n\r\n",gpio_get_level(GPIO_OUTPUT_0));
		vTaskDelay(time_ms);

		gpio_set_level(GPIO_OUTPUT_1,1);                        //GPIO引脚输出函数
		printf("IO18 Level is:%d  \n\r\n",gpio_get_level(GPIO_OUTPUT_1));
		vTaskDelay(time_ms);

		gpio_set_level(GPIO_OUTPUT_1,0);                        //GPIO引脚输出函数
		printf("IO18 Level is:%d  \n\r\n",gpio_get_level(GPIO_OUTPUT_1));
		vTaskDelay(time_ms);

		gpio_set_level(GPIO_OUTPUT_2,1);                        //GPIO引脚输出函数
		printf("IO19 Level is:%d  \n\r\n",gpio_get_level(GPIO_OUTPUT_2));
		vTaskDelay(time_ms);

		gpio_set_level(GPIO_OUTPUT_2,0);                        //GPIO引脚输出函数
		printf("IO19 Level is:%d  \n\r\n",gpio_get_level(GPIO_OUTPUT_2));
		vTaskDelay(time_ms);
		
	}
}
